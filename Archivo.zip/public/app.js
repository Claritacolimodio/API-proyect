import RecomendacionLibro from "./RecomendacionLibro.js"
import Dictionary from "./dictionary.js";
import WordDefinition from "./wordDefinition.js";
import WordSetDefinition from "./wordSetDefinition.js";

class App {
  constructor() {
    this.dictionary = new Dictionary();
    this.onSearch = this.onSearch.bind(this);
    this.onSet = this.onSet.bind(this);
    this.onDelete = this.onDelete.bind(this);
    const searchForm = document.querySelector('#search');
    searchForm.addEventListener('submit', this.onSearch);
    const setForm = document.querySelector('#set');
    setForm.addEventListener('submit', this.onSet);
    const deleteForm = document.querySelector('#delete');
    deleteForm.addEventListener('submit', this.onDelete);

    const logoutButton = document.querySelector("#logout-button");
    logoutButton.addEventListener('click', this.dictionary.logout);


    fetch("/libros_y_peliculas.json")
      .then(response => response.json())
      .then(data => {
        this.libros = data.books;

        const botonBuscarLibro = document.querySelector('#buscar-libro');
        if (botonBuscarLibro) {
          botonBuscarLibro.addEventListener('click', () => {
            const input = document.querySelector('#libro');
            const resultado = document.querySelector('#resultado-libro');
            const libroBuscado = input.value.trim().toLowerCase();

            if (!libroBuscado) {
              resultado.innerHTML = "Escribí un libro.";
              return;
            }

            const encontrado = this.libros.find(libro =>
              libro.title.toLowerCase() === libroBuscado
            );

            if (encontrado) {
              resultado.innerHTML = `
                <div class="recomendacion">
                  <h3>${encontrado.title} - ${encontrado.author}</h3>
                  <img src="${encontrado.bookImage}" alt="Libro" width="120">
                  <p><strong>Género:</strong> ${encontrado.bookGenre}</p>

                  <h4>Película recomendada:</h4>
                  <p><strong>${encontrado.movie.title}</strong> (${encontrado.movie.genre})</p>
                  <img src="${encontrado.movie.image}" alt="Póster" width="120">
                </div>
              `;
            } else {
              resultado.innerHTML = `No se encontró una recomendación para "${libroBuscado}".`;
            }
          });
        }
      });
  }

  onSearch(event) {
    event.preventDefault();
    const status = results.querySelector('#status');
    status.textContent = '';
    const deleteStatus = document.querySelector('#delete-status');
    deleteStatus.textContent = '';
    const input = document.querySelector('#word-input');
    const word = input.value.trim();
    this.dictionary.doLookup(word)
      .then(this.showResults);
  }

  onSet(event) {
    event.preventDefault();
    const resultsContainer = document.querySelector('#results');
    const wordSetDefinition = new WordSetDefinition(resultsContainer);
    const postBody = wordSetDefinition.read();
    const status = results.querySelector('#status');
    status.textContent = '';
    const deleteStatus = document.querySelector('#delete-status');
    deleteStatus.textContent = '';
    this.dictionary.save(postBody)
      .then(result => {
        // Update definition
        new WordDefinition(resultsContainer, postBody);
        status.textContent = 'Saved.';
      });
  }
  
  onDelete(event) {
    event.preventDefault();
    const input = document.querySelector('#word-input-delete');
    const word = input.value.trim();
    this.dictionary.delete(word)
      .then(response => response.json())
      .then (value => {
        const deleteStatus = document.querySelector('#delete-status');
          if (value === null) deleteStatus.textContent = "Word Not Found!";
          else deleteStatus.textContent = "Word Deleted!";
      });
    }

  showResults(result) {
    const resultsContainer = document.querySelector('#results');
    resultsContainer.classList.add('hidden');
    // Show Word Definition.
    new WordDefinition(resultsContainer, result);
    // Prep set definition form.
    const wordSetDefinition = new WordSetDefinition(resultsContainer);
    wordSetDefinition.show(result);
    // Display.
    resultsContainer.classList.remove('hidden');
  }
  
}

// Init app
// Solo inicializar App si está el formulario original
if (document.querySelector('#search')) {
  new App();
}

let botonBuscarPalabra = document.querySelector('#buscar-palabra');
if (botonBuscarPalabra) {
  botonBuscarPalabra.addEventListener('click', () => {
    let palabra = document.querySelector('#palabra').value.trim();
    let resultado = document.querySelector('#resultado-palabra');
    if (!palabra) {
      resultado.textContent = "Escribí una palabra.";
      return;
    }
    resultado.textContent = `Definición simulada de "${palabra}" 🎓`;
  });
}

new App();