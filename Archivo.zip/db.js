import { MongoClient } from "mongodb";

const connectionString = "mongodb+srv://Alejo:Apis2025@cluster0.bviywwz.mongodb.net/";

const client = new MongoClient(connectionString);

let conn;
try {
  // Try
  conn = await client.connect();
} catch(e) {
  console.error(e);
}

let db = conn.db("Austral");

export default db;
