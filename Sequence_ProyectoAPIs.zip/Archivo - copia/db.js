import { MongoClient } from "mongodb";

const connectionString = "mongodb+srv://claracolimodio:Austral25@myproyect25.x9jynmk.mongodb.net/";
const client = new MongoClient(connectionString);

let db;

async function connectToDB() {
  try {
    await client.connect();
    db = client.db("Austral"); // Confirmá si se llama así
    console.log("🟢 Conectado a MongoDB Austral");
  } catch (e) {
    console.error("❌ Error al conectar a MongoDB:", e);
  }
}

await connectToDB();
export default db;
