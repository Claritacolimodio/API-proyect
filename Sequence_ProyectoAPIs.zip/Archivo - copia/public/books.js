const titleHeader = document.getElementById('title-header');
const messageDiv = document.getElementById('message');
const resultDiv = document.getElementById('result');
const notFoundDiv = document.getElementById('not-found');
const movieForm = document.getElementById('movie-form');
const formStatus = document.getElementById('form-status');

const data = localStorage.getItem("libroSeleccionado");
if (!data) {
  titleHeader.innerHTML = '';
  messageDiv.textContent = "No se especificó un libro para buscar.";
  resultDiv.innerHTML = '';
  notFoundDiv.style.display = 'none';
} else {
  try {
    const libro = JSON.parse(data);
    titleHeader.innerHTML = '<h1>Película relacionada al libro</h1>';
    messageDiv.textContent = `Buscando información para: "${libro.title}"`;

    // Mostrar contenido
    resultDiv.innerHTML = `
      <h3>${libro.title} - ${libro.author}</h3>
      <img src="${libro.bookImage}" width="120">
      <p><strong>Género del libro:</strong> ${libro.bookGenre}</p>
      <h4>Película recomendada:</h4>
      <p><strong>${libro.movie.title}</strong> (${libro.movie.genre})</p>
      <img src="${libro.movie.image}" alt="Póster" width="120">
    `;

    // Si viene de MongoDB, tiene _id → permite acciones
    if (libro._id) {
      const btns = document.createElement('div');
      btns.innerHTML = `
        <br>
        <button id="edit-btn">✏️ Editar</button>
        <button id="delete-btn">🗑️ Eliminar</button>
      `;
      resultDiv.appendChild(btns);

      // Guardar ID en localStorage para editar
      localStorage.setItem("libroID", libro._id);

      // Eliminar
      document.getElementById("delete-btn").addEventListener("click", async () => {
        if (confirm("¿Estás seguro de eliminar esta recomendación?")) {
          const res = await fetch(`/api/libros/${libro._id}`, { method: 'DELETE' });
          if (res.ok) {
            alert("Recomendación eliminada.");
            window.location.href = "home.html";
          } else {
            alert("❌ Error al eliminar.");
          }
        }
      });

      // Editar
      document.getElementById("edit-btn").addEventListener("click", () => {
        window.location.href = "editar.html";
      });
    }

  } catch (err) {
    console.error("❌ Error al interpretar el libro del localStorage", err);
    resultDiv.innerHTML = '<p>Error al mostrar la recomendación.</p>';
  }
}

// Agregar nueva película (cuando se habilita el form)
movieForm?.addEventListener('submit', function (event) {
  event.preventDefault();

  const newMovieTitle = document.getElementById('movie-title').value.trim();
  const newMovieYear = document.getElementById('movie-year').value.trim();

  if (newMovieTitle && newMovieYear) {
    formStatus.textContent = '✅ Película cargada correctamente (modo local).';
    resultDiv.innerHTML = `
      <p><strong>Título de la película:</strong> ${newMovieTitle}</p>
      <p><strong>Año:</strong> ${newMovieYear}</p>
    `;
    notFoundDiv.style.display = 'none';
    messageDiv.textContent = `Libro agregado y película relacionada.`;
  } else {
    formStatus.textContent = '⚠️ Por favor, completá todos los campos.';
  }
});
