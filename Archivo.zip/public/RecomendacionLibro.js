class RecomendacionLibro {
  constructor(container, data) {
    container.innerHTML = `
      <h3>${data.title} - ${data.author}</h3>
      <p><strong>Género:</strong> ${data.bookGenre}</p>
      <img src="${data.bookImage}" alt="Portada del libro" width="120"/>

      <h4>Película recomendada:</h4>
      <p><strong>${data.movie.title}</strong> (${data.movie.genre})</p>
      <img src="${data.movie.image}" alt="Poster de la película" width="120"/>
    `;
  }
}

export default RecomendacionLibro;