import express from 'express';
import db from './db.js';
import passport from 'passport';
import Authentication from "./auth.js";
import path from 'path';
import fs from 'fs';
import { ObjectId } from 'mongodb';

const dirname = fs.realpathSync('.');

class DictionaryBackendServer {
  constructor() {
    const app = express();

    app.use(express.json());
    app.use(express.static('public'));
    app.use(express.urlencoded({ extended: false }));

    const authentication = new Authentication(app);

    // Rutas protegidas por autenticación
    app.get('/lookup/:word', authentication.checkAuthenticated, this.doLookup);
    app.post('/save/', authentication.checkAuthenticated, this.doSave);
    app.delete('/delete/', authentication.checkAuthenticated, this.doDelete);

    app.get('/login/', this.login);
    app.get('/', authentication.checkAuthenticated, this.goHome);

    app.get('/auth/google/', passport.authenticate('google', {
      scope: ['email', 'profile']
    }));

    app.get('/auth/google/callback', passport.authenticate('google', {
      successRedirect: '/',
      failureRedirect: '/login'
    }));

    app.post("/logout", (req, res) => {
      req.logOut(err => console.log(err));
      res.redirect("/login");
    });

    // Registro manual
    app.post('/signup', async (req, res) => {
      const { name, email, password } = req.body;
      try {
        const existingUser = await db.collection('users').findOne({ email });
        if (existingUser) return res.redirect('/signup.html?error=exists');

        const newUser = { name, email, password, createdAt: new Date() };
        await db.collection('users').insertOne(newUser);
        res.redirect('/login.html');
      } catch (error) {
        console.error("Error en registro manual:", error);
        res.status(500).send("Error interno");
      }
    });

    // Login manual
    app.post('/login', async (req, res) => {
      const { email, password } = req.body;
      try {
        const user = await db.collection('users').findOne({ email });
        if (!user) return res.redirect('/login.html?error=nouser');
        if (user.password !== password) return res.redirect('/login.html?error=wrongpass');

        req.login(user, (err) => {
          if (err) throw err;
          res.redirect('/');
        });
      } catch (error) {
        console.error("Error en login manual:", error);
        res.status(500).send("Error interno");
      }
    });

    // Guardar libro
    app.post("/api/libros", authentication.checkAuthenticated, async (req, res) => {
      try {
        const libro = {
          ...req.body,
          userEmail: req.user.email,  // 👈 o userId: req.user._id
          createdAt: new Date()
        };
        const resultado = await db.collection("libros").insertOne(libro);
        res.status(201).json({ message: "Recomendación guardada", id: resultado.insertedId });
      } catch (err) {
        console.error("Error guardando libro:", err);
        res.status(500).json({ error: "Error al guardar en MongoDB" });
      }
    });
    

    // Obtener libros
    app.get("/api/libros", authentication.checkAuthenticated, async (req, res) => {
      try {
        const libros = await db.collection("libros").find().toArray();
        res.json(libros);
      } catch (err) {
        console.error("Error obteniendo libros:", err);
        res.status(500).json({ error: "Error al obtener libros de MongoDB" });
      }
    });

    // Eliminar libro
    app.delete("/api/libros/:id", authentication.checkAuthenticated, async (req, res) => {
      try {
        const id = req.params.id;
        const result = await db.collection("libros").deleteOne({ _id: new ObjectId(id) });
        if (result.deletedCount === 0) return res.status(404).json({ error: "Libro no encontrado" });
        res.json({ message: "Libro eliminado correctamente" });
      } catch (err) {
        console.error("Error eliminando libro:", err);
        res.status(500).json({ error: "Error al eliminar en MongoDB" });
      }
    });

    // Actualizar libro
    app.put("/api/libros/:id", authentication.checkAuthenticated, async (req, res) => {
      try {
        const id = req.params.id;
        const data = req.body;
        const result = await db.collection("libros").findOneAndUpdate(
          { _id: new ObjectId(id) },
          { $set: data },
          { returnDocument: 'after' }
        );
        res.json(result.value);
      } catch (err) {
        console.error("Error actualizando libro:", err);
        res.status(500).json({ error: "Error al actualizar en MongoDB" });
      }
    });

    // Iniciar servidor
    app.listen(3000, () => console.log('✅ Servidor escuchando en http://localhost:3000'));
  }

  async login(req, res) {
    res.sendFile(path.join(dirname, "public/login.html"));
  }

  async goHome(req, res) {
    res.sendFile(path.join(dirname, "public/home.html"));
  }

  async doLookup(req, res) {
    const word = req.params.word.toLowerCase();
    const stored = await db.collection("dict").findOne({ word });
    res.json({
      word,
      definition: stored ? stored.definition : ''
    });
  }

  async doSave(req, res) {
    const query = { word: req.body.word.toLowerCase() };
    const update = { $set: { definition: req.body.definition } };
    await db.collection("dict").updateOne(query, update, { upsert: true });
    res.json({ success: true });
  }

  async doDelete(req, res) {
    const word = req.body.word.toLowerCase();
    const deleted = await db.collection("dict").findOneAndDelete({ word });
    res.json(deleted.value);
  }
}

new DictionaryBackendServer();
