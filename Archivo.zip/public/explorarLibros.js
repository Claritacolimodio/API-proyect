const booksContainer = document.getElementById('books-container');


async function fetchBooks() {
 const query = 'fiction'; // ejemplo, puedes modificar
 const maxResults = 20;
 const url = `https://www.googleapis.com/books/v1/volumes?q=${query}&maxResults=${maxResults}`;


 try {
   const res = await fetch(url);
   const data = await res.json();


   if (!data.items) {
     booksContainer.innerHTML = '<p>No se encontraron libros.</p>';
     return;
   }


   // Limpiar contenedor
   booksContainer.innerHTML = '';


   // Crear lista ul
   const ul = document.createElement('ul');
   ul.style.padding = '0';  // por si acaso


   data.items.forEach(book => {
     const li = document.createElement('li');
     li.className = 'book-item';


     // Imagen - redirige a books.html con id
     const img = document.createElement('img');
     img.src = book.volumeInfo.imageLinks?.thumbnail || 'https://via.placeholder.com/80x120?text=No+Image';
     img.alt = book.volumeInfo.title;
     img.addEventListener('click', () => {
       // Aquí puedes mandar id o info que necesites para la página books.html
       // Por ejemplo con query string:
       window.location.href = `books.html?id=${book.id}`;
     });


     // Detalles
     const details = document.createElement('div');
     details.className = 'book-details';


     const title = document.createElement('h3');
     title.className = 'book-title';
     title.textContent = book.volumeInfo.title || 'Sin título';


     const author = document.createElement('p');
     author.className = 'book-author';
     author.textContent = book.volumeInfo.authors ? book.volumeInfo.authors.join(', ') : 'Autor desconocido';


     details.appendChild(title);
     details.appendChild(author);


     li.appendChild(img);
     li.appendChild(details);


     ul.appendChild(li);
   });


   booksContainer.appendChild(ul);
 } catch (error) {
   console.error('Error al cargar libros:', error);
   booksContainer.innerHTML = '<p>Error cargando los libros.</p>';
 }
}


fetchBooks();