import express from 'express';
import db from './db.js';
import passport from 'passport';
import Authentication from "./auth.js";
import path from 'path';
import fs from 'fs';

const dirname = fs.realpathSync('.');

class DictionaryBackendServer {
  constructor() {
    const app = express();
    app.use(express.json());
    app.use(express.static('public'));
    app.use(express.urlencoded({ extended: false }));
    const authentication = new Authentication(app);

    // Rutas del diccionario
    app.get('/lookup/:word', authentication.checkAuthenticated, this.doLookup);
    app.post('/save/',       authentication.checkAuthenticated, this.doSave);
    app.delete('/delete/',   authentication.checkAuthenticated, this.doDelete);

    // Ruta para guardar relaciones libro ↔ película
    app.post(
      '/guardarRelacion',
      authentication.checkAuthenticated,
      async (req, res) => {
        const data = req.body;
        const usuario = req.user.email;

        if (
          !data.title ||
          !data.author ||
          !data.bookGenre ||
          !data.movie ||
          !data.movie.title ||
          !data.movie.genre
        ) {
          return res
            .status(400)
            .json({ error: 'Faltan campos requeridos en el body' });
        }

        try {
          await db.collection('relaciones').insertOne({
            usuario,
            title: data.title,
            author: data.author,
            bookGenre: data.bookGenre,
            movie: {
              title: data.movie.title,
              genre: data.movie.genre
            },
            timestamp: new Date()
          });
          res.json({ mensaje: 'Relación guardada exitosamente' });
        } catch (e) {
          console.error('Error al guardar relación:', e);
          res
            .status(500)
            .json({ error: 'No se pudo guardar la relación en la base' });
        }
      }
    );

    // Nueva ruta para buscar en Mongo la relación por título
    app.get(
      '/api/libros',
      authentication.checkAuthenticated,
      async (req, res) => {
        const title = req.query.title;
        if (!title) {
          return res.status(400).json({ error: 'Falta el parámetro title' });
        }
        try {
          const col = db.collection('relaciones');
          const doc = await col.findOne({
            title: { $regex: `^${title}$`, $options: 'i' }
          });
          if (!doc) {
            return res
              .status(404)
              .json({ mensaje: 'No se encontró relación para ese libro' });
          }
          res.json(doc);
        } catch (e) {
          console.error('Error al buscar relación:', e);
          res.status(500).json({ error: 'Error interno del servidor' });
        }
      }
    );

    // Rutas de login y home
    app.get('/login/', this.login);
    app.get('/', authentication.checkAuthenticated, this.goHome);

    // OAuth Google
    app.get(
      '/auth/google/',
      passport.authenticate('google', {
        scope: ['email', 'profile']
      })
    );
    app.get(
      '/auth/google/callback',
      passport.authenticate('google', {
        successRedirect: '/',
        failureRedirect: '/login'
      })
    );
    app.post("/logout", (req, res) => {
      req.logOut(err => console.error(err));
      res.redirect("/login");
    });

    // Inicia el servidor
    app.listen(3000, () => console.log('Listening on port 3000'));
  }

  async login(req, res) {
    res.sendFile(path.join(dirname, "public/login.html"));
  }

  async goHome(req, res) {
    res.sendFile(path.join(dirname, "public/home.html"));
  }

  async doLookup(req, res) {
    const word = req.params.word.toLowerCase();
    const stored = await db.collection("dict").findOne({ word });
    res.json({
      word,
      definition: stored ? stored.definition : ''
    });
  }

  async doSave(req, res) {
    const word = req.body.word.toLowerCase();
    await db
      .collection("dict")
      .updateOne({ word }, { $set: { definition: req.body.definition } }, { upsert: true });
    res.json({ success: true });
  }

  async doDelete(req, res) {
    const word = req.body.word.toLowerCase();
    const deleted = await db.collection("dict").findOneAndDelete({ word });
    res.json(deleted.value);
  }
}

new DictionaryBackendServer();
