document.addEventListener("DOMContentLoaded", () => {
  const libroData = JSON.parse(localStorage.getItem("libroEditar"));
  if (!libroData) {
    document.body.innerHTML = "<p>No se encontró la recomendación para editar.</p>";
    return;
  }

  // Mostrar datos actuales
  document.getElementById("title").value = libroData.title;
  document.getElementById("author").value = libroData.author;
  document.getElementById("bookGenre").value = libroData.bookGenre;
  document.getElementById("bookImage").value = libroData.bookImage;

  const moviesContainer = document.getElementById("movies-container");
  const movies = Array.isArray(libroData.movie) ? libroData.movie : [libroData.movie];

  movies.forEach((pelicula, i) => {
    const wrapper = document.createElement("div");
    wrapper.classList.add("movie-entry");

    wrapper.innerHTML = `
      <label>Película ${i + 1} título:</label>
      <input name="movieTitle" value="${pelicula.title}" required>
      <label>Género:</label>
      <input name="movieGenre" value="${pelicula.genre}" required>
      <label>Imagen (URL):</label>
      <input name="movieImage" value="${pelicula.image}" required>
    `;

    moviesContainer.appendChild(wrapper);
  });

  document.getElementById("agregar-pelicula").addEventListener("click", () => {
    const wrapper = document.createElement("div");
    wrapper.classList.add("movie-entry");
    wrapper.innerHTML = `
      <label>Título de película:</label>
      <input name="movieTitle" required>
      <label>Género:</label>
      <input name="movieGenre" required>
      <label>Imagen (URL):</label>
      <input name="movieImage" required>
    `;
    moviesContainer.appendChild(wrapper);
  });

  document.getElementById("form-editar").addEventListener("submit", async (e) => {
    e.preventDefault();

    const data = {
      title: document.getElementById("title").value,
      author: document.getElementById("author").value,
      bookGenre: document.getElementById("bookGenre").value,
      bookImage: document.getElementById("bookImage").value,
      movie: []
    };

    const titles = document.getElementsByName("movieTitle");
    const genres = document.getElementsByName("movieGenre");
    const images = document.getElementsByName("movieImage");

    for (let i = 0; i < titles.length; i++) {
      data.movie.push({
        title: titles[i].value,
        genre: genres[i].value,
        image: images[i].value
      });
    }

    try {
      const res = await fetch(`/api/libros/${libroData._id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      if (res.ok) {
        alert("✅ Recomendación actualizada");
        window.location.href = "home.html";
      } else {
        alert("❌ Error al actualizar");
      }
    } catch (err) {
      console.error("Error:", err);
      alert("❌ Fallo técnico al enviar.");
    }
  });
});
