const booksContainer = document.getElementById('books-container');

const idsPermitidos = [
  '1N0KDgAAQBAJ',
  '2zgRDXFWkm8C',
  'HymbEAAAQBAJ',
  'z4u_EAAAQBAJ',
  'aSbjm40TcnsC',
  'vPUC0AEACAAJ'
];

async function fetchBooksPorID() {
  booksContainer.innerHTML = ''; // limpiar

  const ul = document.createElement('ul');
  ul.style.padding = '0';

  for (const id of idsPermitidos) {
    try {
      const res = await fetch(`https://www.googleapis.com/books/v1/volumes/${id}`);
      const book = await res.json();

      const li = document.createElement('li');
      li.className = 'book-item';

      const img = document.createElement('img');
      img.src = book.volumeInfo.imageLinks?.thumbnail || 'https://via.placeholder.com/80x120?text=No+Image';
      img.alt = book.volumeInfo.title;
      img.addEventListener('click', () => {
        window.location.href = `books.html?id=${book.id}`;
      });

      const details = document.createElement('div');
      details.className = 'book-details';

      const title = document.createElement('h3');
      title.className = 'book-title';
      title.textContent = book.volumeInfo.title || 'Sin título';

      const author = document.createElement('p');
      author.className = 'book-author';
      author.textContent = book.volumeInfo.authors ? book.volumeInfo.authors.join(', ') : 'Autor desconocido';

      details.appendChild(title);
      details.appendChild(author);

      li.appendChild(img);
      li.appendChild(details);

      ul.appendChild(li);
    } catch (error) {
      console.error(`Error cargando libro con id ${id}:`, error);
    }
  }

  booksContainer.appendChild(ul);
}

fetchBooksPorID();
