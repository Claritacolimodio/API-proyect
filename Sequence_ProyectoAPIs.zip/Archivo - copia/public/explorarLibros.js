const booksContainer = document.getElementById('books-container');
const JSON_URL = "https://raw.githubusercontent.com/Claritacolimodio/API-proyect/refs/heads/main/libros_y_peliculas.json";

async function fetchBooks() {
  try {
    const [jsonRes, apiRes] = await Promise.all([
      fetch(JSON_URL),
      fetch("/api/libros") // Autenticado
    ]);

    const jsonData = await jsonRes.json();
    const apiData = await apiRes.json();

    const books = [...(jsonData.books || []), ...apiData];

    if (!books.length) {
      booksContainer.innerHTML = '<p>No se encontraron libros.</p>';
      return;
    }

    booksContainer.innerHTML = '';
    const ul = document.createElement('ul');
    ul.style.padding = '0';

    books.forEach(book => {
      const li = document.createElement('li');
      li.className = 'book-item';

      const img = document.createElement('img');
      img.src = book.bookImage || 'https://via.placeholder.com/80x120?text=No+Image';
      img.alt = book.title;
      img.style.cursor = 'pointer';
      img.addEventListener('click', () => {
        localStorage.setItem("libroSeleccionado", JSON.stringify(book));
        window.location.href = 'books.html';
      });

      const details = document.createElement('div');
      details.className = 'book-details';

      const title = document.createElement('h3');
      title.className = 'book-title';
      title.textContent = book.title;

      const author = document.createElement('p');
      author.className = 'book-author';
      author.textContent = `Autor: ${book.author}`;

      const genre = document.createElement('p');
      genre.className = 'book-genre';
      genre.textContent = `Género: ${book.bookGenre}`;

      details.appendChild(title);
      details.appendChild(author);
      details.appendChild(genre);
      li.appendChild(img);
      li.appendChild(details);
      ul.appendChild(li);
    });

    booksContainer.appendChild(ul);

  } catch (error) {
    console.error("❌ Error al combinar fuentes:", error);
    booksContainer.innerHTML = '<p>Error al conectar con las fuentes de datos.</p>';
  }
}

fetchBooks();
