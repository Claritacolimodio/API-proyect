export default class RecomendacionLibro {
  constructor(container, libro) {
    if (!libro || !container) return;

    container.innerHTML = `
      <h2>${libro.title} - ${libro.author}</h2>
      <img src="${libro.bookImage}" width="120">
      <p><strong>Género del libro:</strong> ${libro.bookGenre}</p>
      <h3>Películas recomendadas:</h3>
      <div id="peliculas-listado"></div>
      <div id="acciones-libro" style="margin-top: 20px;"></div>
    `;

    const peliculas = Array.isArray(libro.movie) ? libro.movie : [libro.movie];
    const lista = document.getElementById("peliculas-listado");

    peliculas.forEach(p => {
      const div = document.createElement("div");
      div.innerHTML = `
        <p><strong>${p.title}</strong> (${p.genre})</p>
        <img src="${p.image}" width="100" style="margin-bottom: 10px;">
        <hr/>
      `;
      lista.appendChild(div);
    });

    const acciones = document.getElementById("acciones-libro");

    // Botón editar
    const editBtn = document.createElement("button");
    editBtn.textContent = "✏️ Editar recomendación";
    editBtn.onclick = () => {
      localStorage.setItem("libroEditar", JSON.stringify(libro));
      window.location.href = "editar.html";
    };

    // Botón eliminar
    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "🗑 Eliminar recomendación";
    deleteBtn.onclick = async () => {
      const confirmar = confirm(`¿Eliminar "${libro.title}"?`);
      if (!confirmar) return;
      const res = await fetch(`/api/libros/${libro._id}`, { method: 'DELETE' });
      if (res.ok) {
        alert("✅ Eliminado");
        window.location.href = "home.html";
      } else {
        alert("❌ Error al eliminar.");
      }
    };

    acciones.appendChild(editBtn);
    acciones.appendChild(deleteBtn);
  }
}
