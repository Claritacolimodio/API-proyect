const titleHeader = document.getElementById('title-header');

if (!bookTitle) {
  messageDiv.textContent = "No se especificó un libro para buscar.";
  resultDiv.innerHTML = '';
  notFoundDiv.style.display = 'none';
  titleHeader.innerHTML = ''; // no mostrar título
} else {
  titleHeader.innerHTML = '<h1>Película relacionada al libro</h1>';
  messageDiv.textContent = `Buscando información para: "${bookTitle}"`;
}

const booksDB = {
    'El señor de los anillos': { movieTitle: 'The Lord of the Rings', movieYear: 2001 },
    'Harry Potter': { movieTitle: 'Harry Potter and the Sorcerer\'s Stone', movieYear: 2001 },
    'Juego de tronos': { movieTitle: 'Game of Thrones', movieYear: 2011 }
  };
  
  // Función para obtener parámetros de URL
  function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
  }
  
  const messageDiv = document.getElementById('message');
  const resultDiv = document.getElementById('result');
  const notFoundDiv = document.getElementById('not-found');
  
  const bookTitle = getQueryParam('title');
  
  if (!bookTitle) {
    messageDiv.textContent = "No se especificó un libro para buscar.";
    resultDiv.innerHTML = '';
    notFoundDiv.style.display = 'none';
  } else {
    messageDiv.textContent = `Buscando información para: "${bookTitle}"`;
  
    if (booksDB[bookTitle]) {
      // Libro encontrado
      const movie = booksDB[bookTitle];
      notFoundDiv.style.display = 'none';
      resultDiv.innerHTML = `
        <p><strong>Título de la película:</strong> ${movie.movieTitle}</p>
        <p><strong>Año:</strong> ${movie.movieYear}</p>
      `;
    } else {
      // Libro no encontrado
      resultDiv.innerHTML = '';
      notFoundDiv.style.display = 'block';
    }
  }
  
  // Manejo del formulario para agregar película
  const movieForm = document.getElementById('movie-form');
  const formStatus = document.getElementById('form-status');
  
  movieForm.addEventListener('submit', function(event) {
    event.preventDefault();
  
    const newMovieTitle = document.getElementById('movie-title').value.trim();
    const newMovieYear = document.getElementById('movie-year').value.trim();
  
    if (newMovieTitle && newMovieYear) {
      // Guardar en la "base" (aquí sólo en memoria)
      booksDB[bookTitle] = {
        movieTitle: newMovieTitle,
        movieYear: parseInt(newMovieYear)
      };
  
      formStatus.textContent = 'Película cargada correctamente!';
  
      // Mostrar la info de la película
      resultDiv.innerHTML = `
        <p><strong>Título de la película:</strong> ${newMovieTitle}</p>
        <p><strong>Año:</strong> ${newMovieYear}</p>
      `;
      notFoundDiv.style.display = 'none';
      messageDiv.textContent = `Libro agregado y película relacionada: "${bookTitle}"`;
    } else {
      formStatus.textContent = 'Por favor, completá todos los campos.';
    }
  });
  
